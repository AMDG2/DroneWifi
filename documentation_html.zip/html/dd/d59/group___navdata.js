var group___navdata =
[
    [ "initNavData", "dd/d59/group___navdata.html#gadc9b2978300453d233c53cbf1843f12f", null ],
    [ "receiveNavData", "dd/d59/group___navdata.html#ga03605265ec56c4425b17e01f84dac1b7", null ],
    [ "sendNavData", "dd/d59/group___navdata.html#gaf6174a6461979c55f30f38f91214d432", null ]
];