var group___i_o =
[
    [ "BRDInit", "d7/d64/group___i_o.html#ga9cb15ec1781380780672afe306a163ec", null ],
    [ "ecrireCommandes", "d7/d64/group___i_o.html#ga8db22cd26deb1fc2f3c2aedcf509419b", null ],
    [ "init_etat_commandes", "d7/d64/group___i_o.html#ga47503442984c9244a27e7b95ffa472c3", null ],
    [ "lireCommandes", "d7/d64/group___i_o.html#ga91ea6d792c13305827a81e66a1eedf87", null ],
    [ "print_etat_commandes", "d7/d64/group___i_o.html#ga1ef495708616d7a4109d342e590397e9", null ],
    [ "SPI_CLK", "d7/d64/group___i_o.html#gaf61e8f99c1568bc62cd24251e4cc0fa2", null ],
    [ "SPI_CS", "d7/d64/group___i_o.html#gab5cfdcd0547c9f87516a805b4849d64f", null ],
    [ "SPI_delay", "d7/d64/group___i_o.html#ga2add26338df32b959cc94b45daa49a95", null ],
    [ "SPI_DIN", "d7/d64/group___i_o.html#ga831fe77ab7ce75ba9a41ecb3c08a97d9", null ],
    [ "SPI_DOUT", "d7/d64/group___i_o.html#ga837457e63fcbfcc6e59b6d4c59bd7252", null ],
    [ "SPIread", "d7/d64/group___i_o.html#ga5232f075d5cd2577d072721a1494eb03", null ]
];