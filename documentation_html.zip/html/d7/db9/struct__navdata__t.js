var struct__navdata__t =
[
    [ "ardrone_state", "d7/db9/struct__navdata__t.html#a9885b248b2e999efbefc290cb3498160", null ],
    [ "header", "d7/db9/struct__navdata__t.html#abb4e7d30bf6f78c55f2118cd97a9ae24", null ],
    [ "options", "d7/db9/struct__navdata__t.html#af90247adeee1fae914196a1ba5f72363", null ],
    [ "sequence", "d7/db9/struct__navdata__t.html#a0ab03ef2cc38198d3666a992a245fddf", null ],
    [ "vision_defined", "d7/db9/struct__navdata__t.html#a75173e641d84e71dfd0cd5413260419d", null ],
    [ "vision_defined", "d7/db9/struct__navdata__t.html#a01e5bf7e91f13415e6bbfa5e39484b40", null ]
];