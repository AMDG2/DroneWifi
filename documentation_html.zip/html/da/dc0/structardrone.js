var structardrone =
[
    [ "addrDroneAT", "da/dc0/structardrone.html#a3abc6f7414887cc348bc42cfb31fb2aa", null ],
    [ "addrDroneNavDataR", "da/dc0/structardrone.html#a1966e382437efb808ca410464e6df3a2", null ],
    [ "addrDroneNavDataW", "da/dc0/structardrone.html#a2061d0b2124146916aff1fc11d9ec69a", null ],
    [ "buff", "da/dc0/structardrone.html#a5e0dcceff10892315cf82045e4557c08", null ],
    [ "bufferLeft", "da/dc0/structardrone.html#ab80b3b3d9521bd3d4210213a867fd5e3", null ],
    [ "bufferRight", "da/dc0/structardrone.html#ad476a560eb88b1f0ce94fd0096dfea60", null ],
    [ "fly", "da/dc0/structardrone.html#add082aec46aabcfff152690149e62b92", null ],
    [ "fly", "da/dc0/structardrone.html#a9d1fad21c1121fc07e7f54ae86754cac", null ],
    [ "goUpDown", "da/dc0/structardrone.html#a16b56e326c383a1c8e65b9606394d8d8", null ],
    [ "hostInfo", "da/dc0/structardrone.html#ae447ec8b5a05873fcaf0a4c0aebe7527", null ],
    [ "ident", "da/dc0/structardrone.html#a52e7dc3872878f8c40cd3523fed00c80", null ],
    [ "port_at", "da/dc0/structardrone.html#a00fc5c8d8c6b90f8711d47d6e84a1783", null ],
    [ "port_at", "da/dc0/structardrone.html#aa897b5cf8c9c2925080d3f8e7b5e6e45", null ],
    [ "port_navdata", "da/dc0/structardrone.html#aa4b7c68374b0450ba6f92fa0c3df55a9", null ],
    [ "tiltFrontBack", "da/dc0/structardrone.html#ab7595e72cef7c0d9b420ca761a99f925", null ],
    [ "tiltLeftRight", "da/dc0/structardrone.html#aab3abade7277342dcf6993e39ab33958", null ],
    [ "turnLeftRight", "da/dc0/structardrone.html#a4957a05f1b914dbb986928dff3dd9699", null ],
    [ "udpSocket_at", "da/dc0/structardrone.html#a3ad06ac3b164a63e113ec5d103a7ba5d", null ],
    [ "udpSocket_at", "da/dc0/structardrone.html#acb3a788ee7164c5350b4bfd7d8312772", null ],
    [ "udpSocket_navData", "da/dc0/structardrone.html#ac3a32180c7f20eead8d67e6e4587f0bb", null ]
];