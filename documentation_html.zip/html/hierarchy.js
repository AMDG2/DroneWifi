var hierarchy =
[
    [ "_navdata_demo_t", "d6/dfd/struct__navdata__demo__t.html", null ],
    [ "_navdata_option_t", "d3/d57/struct__navdata__option__t.html", null ],
    [ "_navdata_t", "d7/db9/struct__navdata__t.html", null ],
    [ "ardrone", "da/dc0/structardrone.html", null ],
    [ "etat_commandes", "d9/dfc/structetat__commandes.html", null ],
    [ "joystick", "d4/da4/unionjoystick.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "d9/dc6/class_main_window.html", null ]
    ] ],
    [ "QThread", null, [
      [ "ARDrone", "de/d57/class_a_r_drone.html", null ]
    ] ]
];