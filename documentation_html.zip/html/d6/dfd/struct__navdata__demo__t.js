var struct__navdata__demo__t =
[
    [ "altitude", "d6/dfd/struct__navdata__demo__t.html#a5402881d7f8a92e6838995507bf2e7f9", null ],
    [ "ctrl_state", "d6/dfd/struct__navdata__demo__t.html#a8f9f4d759ea843b8b6becfb4a5dfc6e0", null ],
    [ "num_frames", "d6/dfd/struct__navdata__demo__t.html#aae6a7c7e1a07ffcdbcb0b1120484c443", null ],
    [ "phi", "d6/dfd/struct__navdata__demo__t.html#aae1e616b45b6e2efa066845be61cb17f", null ],
    [ "psi", "d6/dfd/struct__navdata__demo__t.html#ae56a558f8e8d836b1fe5ce184dae0c78", null ],
    [ "size", "d6/dfd/struct__navdata__demo__t.html#aaba88b24a21a6c70c895c0d55f4a69a0", null ],
    [ "tag", "d6/dfd/struct__navdata__demo__t.html#a069d5e423ac499380d877123286e1792", null ],
    [ "theta", "d6/dfd/struct__navdata__demo__t.html#ab3005177a8e23ca1859497aae713ea53", null ],
    [ "vbat_flying_percentage", "d6/dfd/struct__navdata__demo__t.html#a73c36d8b9a18e243141998cdfd790ce4", null ],
    [ "vx", "d6/dfd/struct__navdata__demo__t.html#a143bfef02c586e55dc3b20ad3a2c05e9", null ],
    [ "vy", "d6/dfd/struct__navdata__demo__t.html#aed55c085dcc8e5f48dbd48d5c7e79ef7", null ],
    [ "vz", "d6/dfd/struct__navdata__demo__t.html#aa27afb3cab0ad66a5f04677bbff8bf16", null ]
];