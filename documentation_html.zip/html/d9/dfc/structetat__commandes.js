var structetat__commandes =
[
    [ "bp_arret_urgence", "d9/dfc/structetat__commandes.html#adcce0767b69b6aa61d9815c90afece60", null ],
    [ "bp_trim", "d9/dfc/structetat__commandes.html#adc9e1c40950878e4b174300aef5c8628", null ],
    [ "bp_video", "d9/dfc/structetat__commandes.html#a9f65380fb32037e5147720cbd1c20cad", null ],
    [ "bpj1", "d9/dfc/structetat__commandes.html#a591c053434ce27506928147bdeb8a8e0", null ],
    [ "bpj2", "d9/dfc/structetat__commandes.html#ac1836ed49ec06d343dc4ad8a66815325", null ],
    [ "joystick_1x", "d9/dfc/structetat__commandes.html#aefd8dcb52ec6c8b5014e4e4a07ce36f5", null ],
    [ "joystick_1y", "d9/dfc/structetat__commandes.html#a44464264b58e816437b75338c8071db7", null ],
    [ "joystick_2x", "d9/dfc/structetat__commandes.html#ab13efe455d7039d936ed7c8909581001", null ],
    [ "joystick_2y", "d9/dfc/structetat__commandes.html#a22286f59a64543f8e90ee521270110bd", null ],
    [ "led_connecte", "d9/dfc/structetat__commandes.html#a38345f0aebb4de891510939a4d1b6d3f", null ],
    [ "led_debug", "d9/dfc/structetat__commandes.html#aa6c5f40a4dec71b510d913e4c09e3cee", null ],
    [ "led_erreur", "d9/dfc/structetat__commandes.html#a3aaef46c6ca19a2afb10c86c5300d067", null ],
    [ "switch_land", "d9/dfc/structetat__commandes.html#af0fce6b96a884e05a43ec95b76d1f6db", null ]
];