var struct__navdata__option__t =
[
    [ "data", "d3/d57/struct__navdata__option__t.html#a7f897df1949af68456ee830f2468e476", null ],
    [ "size", "d3/d57/struct__navdata__option__t.html#aaba88b24a21a6c70c895c0d55f4a69a0", null ],
    [ "tag", "d3/d57/struct__navdata__option__t.html#a069d5e423ac499380d877123286e1792", null ]
];