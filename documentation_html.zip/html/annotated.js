var annotated =
[
    [ "Ui", "dc/df0/namespace_ui.html", null ],
    [ "_navdata_demo_t", "d6/dfd/struct__navdata__demo__t.html", "d6/dfd/struct__navdata__demo__t" ],
    [ "_navdata_option_t", "d3/d57/struct__navdata__option__t.html", "d3/d57/struct__navdata__option__t" ],
    [ "_navdata_t", "d7/db9/struct__navdata__t.html", "d7/db9/struct__navdata__t" ],
    [ "ardrone", "da/dc0/structardrone.html", "da/dc0/structardrone" ],
    [ "ARDrone", "de/d57/class_a_r_drone.html", "de/d57/class_a_r_drone" ],
    [ "etat_commandes", "d9/dfc/structetat__commandes.html", "d9/dfc/structetat__commandes" ],
    [ "joystick", "d4/da4/unionjoystick.html", "d4/da4/unionjoystick" ],
    [ "MainWindow", "d9/dc6/class_main_window.html", "d9/dc6/class_main_window" ]
];