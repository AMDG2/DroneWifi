var searchData=
[
  ['_7emainwindow',['~MainWindow',['../d9/dc6/class_main_window.html#aa33fa7d45aa34b9ede5cb69ab574a1b2',1,'MainWindow']]]
];
