var searchData=
[
  ['max_5fudp_5fsocket_5fbuffers',['MAX_UDP_SOCKET_BUFFERS',['../d0/d29/main_8c.html#acfff4a297a5d2f7707464fdeb4f18315',1,'main.c']]]
];
