var searchData=
[
  ['keypressevent',['keyPressEvent',['../d9/dc6/class_main_window.html#a9253afdeb949951bc710a2967917f399',1,'MainWindow']]],
  ['keyreleaseevent',['keyReleaseEvent',['../d9/dc6/class_main_window.html#a66314b9bfdbbdc580abde82c0ebef272',1,'MainWindow']]]
];
