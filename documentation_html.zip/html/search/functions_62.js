var searchData=
[
  ['brdinit',['BRDInit',['../d7/d64/group___i_o.html#ga9cb15ec1781380780672afe306a163ec',1,'main.c']]]
];
