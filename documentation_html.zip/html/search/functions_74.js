var searchData=
[
  ['takeoff',['takeoff',['../de/d57/class_a_r_drone.html#a34d3e2ff71b9fc05e2faa20015d320c8',1,'ARDrone::takeoff()'],['../d9/d77/group___a_t_commands.html#gab921594f80039784a2fcb17796744613',1,'takeoff(ardrone *dr):&#160;ardrone.c'],['../d9/d77/group___a_t_commands.html#gab921594f80039784a2fcb17796744613',1,'takeoff(ardrone *dr):&#160;ardrone.c'],['../d9/d77/group___a_t_commands.html#gab921594f80039784a2fcb17796744613',1,'takeoff(ardrone *dr):&#160;ardrone.c']]]
];
