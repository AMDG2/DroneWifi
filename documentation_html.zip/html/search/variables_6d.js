var searchData=
[
  ['mode',['mode',['../d9/dc6/class_main_window.html#a1ea5d0cb93f22f7d0fdf804bd68c3326',1,'MainWindow']]]
];
