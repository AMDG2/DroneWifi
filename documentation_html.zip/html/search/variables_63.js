var searchData=
[
  ['connect',['connect',['../d0/d29/main_8c.html#a6c0592b34aa72ee716e9c0b939038faa',1,'main.c']]],
  ['ctrl_5fstate',['ctrl_state',['../d6/dfd/struct__navdata__demo__t.html#a8f9f4d759ea843b8b6becfb4a5dfc6e0',1,'_navdata_demo_t']]]
];
